# Timeline IE

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvarotrigo/pen/yLzBJaN](https://codepen.io/alvarotrigo/pen/yLzBJaN).

